# Spring Boot "Microservice" Employee Management Project

### Requirements for development

```
JDK 8
Maven 3.2.5
```

### Requirements for production

```
JDK 8
It uses H2 In-Memory Data Base

```

Here are some endpoints you can call:

Get all employees 
http://localhost:8110/api/employees

Get Employee by Id 
http://localhost:8110/api/employees/1

Create new employee 
http://localhost:8110/api/employees 

{
    "empname": "Thanvika",
    "designation": "Programmer",
    "email": "thanudhamodharan@gmal.com",
    "phone": "9629016324",
    "address": "Erode"
}

Update employee 
http://localhost:8110/api/employees/1

{
    "empname": "Thanvika",
    "designation": "Programmer",
    "email": "thanudhamodharan@gmal.com",
    "phone": "9629016324",
    "address": "Erode"
}

Delete employee 
http://localhost:8110/api/employees/1 
