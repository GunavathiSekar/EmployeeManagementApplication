package com.demo.employeeApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.demo.employeeApplication.model.Employee;
import com.demo.employeeApplication.repository.EmployeeRepository;
/*
 * Employee RESTful API endpoints using Spring MVC
 */
import com.demo.employeeApplication.util.Constants;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;

	/*
	 * Get All the Employees exist in the table
	 */

	@GetMapping("/employees")
	@ResponseStatus(HttpStatus.OK)
	public List<Employee> findAllEmployees() {
		return employeeRepository.findAll();
	}

	/*
	 * Search the employee by Employee Id
	 */

	@GetMapping("/employees/{id}")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody Employee findEmployeeById(@PathVariable(value = "id") Long employeeId)
			throws Exception {
		if (employeeId != null) {
			return employeeRepository.findById(employeeId).get();
		} else {
			throw new Exception("Employee Id is null");
		}
	}

	/*
	 * Post the new Employee
	 */

	@RequestMapping(value = "/employees",
	            method = RequestMethod.POST,
	            consumes = {Constants.REQUEST_CONTENT_TYPE},
	            produces = {Constants.REQUEST_CONTENT_TYPE})
	@ResponseStatus(HttpStatus.CREATED)
	public Employee addEmployee(@RequestBody Employee employee) throws Exception {
		if(employee !=null) {
		employee.setId(null);
		return employeeRepository.save(employee);}
		else {
			throw new Exception("Employee Id is null");	
		}
	}
	/*
	 * Update the Employee by Id
	 */

	@RequestMapping(value = "/employees/{id}",
    method = RequestMethod.PUT,
    consumes = {Constants.REQUEST_CONTENT_TYPE},
    produces = {Constants.REQUEST_CONTENT_TYPE})
	@ResponseStatus(HttpStatus.OK)
	public Employee updateEmployee(@RequestBody Employee employee, @PathVariable(value = "id") Long employeeId)
			throws Exception {
		if (employeeId != null) {
			employee.setId(employeeId);
			return employeeRepository.save(employee);
		} else {
			throw new Exception("Employee Id is null");
		}
	}

	/*
	 * Delete the Employee by Id
	 */

	@DeleteMapping("/employees/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void deleteEmployeeById(@PathVariable(value = "id") Long employeeId) throws Exception {
		if (employeeId != null) {
			employeeRepository.deleteById(employeeId);
		} else {
			throw new Exception("Employee Id is null");
		}
	}

}
