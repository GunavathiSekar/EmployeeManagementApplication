package com.demo.employeeApplication.util;

public class Constants {
	public final static String REQUEST_CONTENT_TYPE = "application/json";
	public final static String REQUEST_CONTENT_TYPE_UTF = "application/json; charset=utf-8";
	public final static String ERR_CODE_BAD_FORMAT = "BAD_FORMAT";
	public final static String ERR_MSG_MISSING_FIELD_VALUE = "%s is required";

}
