DROP TABLE IF EXISTS Employee;

CREATE TABLE Employee (
  id Long AUTO_INCREMENT  PRIMARY KEY,
  empname VARCHAR(250) NOT NULL,
  designation VARCHAR(250) NOT NULL,
  email VARCHAR(250) DEFAULT NULL,
  phone VARCHAR(10) DEFAULT NULL,
  address VARCHAR(250) DEFAULT NULL
  
);

INSERT INTO Employee (empname, designation,email,phone,address) VALUES
  ('Gunavathi', 'Programmer', 'gunavathisekar@gmal.com','9629016324','Erode');
