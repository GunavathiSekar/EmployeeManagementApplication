import { Component, OnInit } from '@angular/core';
import { HttpClientService, Employee } from '../service/httpclient.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

   id!: number;
  
  user: Employee = new Employee("","","","","","");
  constructor(private route: ActivatedRoute,private router: Router,
    private httpClientService: HttpClientService) { }

  ngOnInit() {
   this.id = this.route.snapshot.params['id'];
    this.httpClientService.getEmployee(this.id)
      .subscribe(data => {
        console.log(data)
        this.user = data;
      }, error => console.log(error)); 
  }

  updateEmployee() {
    console.log("datattaaaa",this.user);
    this.httpClientService.updateEmployee(this.user)
      .subscribe(data => {
        console.log(data);
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateEmployee();    
  }

  gotoList() {
    this.router.navigate(['/']);
  }

}
