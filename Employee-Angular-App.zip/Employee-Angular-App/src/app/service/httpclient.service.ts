import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export class Employee{
  constructor(
    public id:string,
    public empname:string,
    public designation:string,
    public email:string,
    public phone:string,
    public address:string,
  ) {}
}

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(
    private httpClient:HttpClient
  ) { 
     }

     getEmployees()
  {
    console.log("test call");
    return this.httpClient.get<Employee[]>('http://localhost:8110/api/employees');
  }

  public deleteEmployee(empid) {
    return this.httpClient.delete<Employee>("http://localhost:8110/api/employees" + "/"+ empid);
  }

  public createEmployee(employee) {
    return this.httpClient.post<Employee>("http://localhost:8110/api/employees", employee);
  }

  updateEmployee(employee): Observable<Object> {
    return this.httpClient.put("http://localhost:8110/api/employees"+ "/"+ employee.id, employee);
  }

  getEmployee(empid)
  {
    console.log("test call");
    return this.httpClient.get<Employee>('http://localhost:8110/api/employees'+ "/"+ empid);
  }
}