import { Component, OnInit } from '@angular/core';
import { HttpClientService, Employee } from '../service/httpclient.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employees:Employee[];
  user: Employee = new Employee("","","","","","");
   
  constructor(
    private httpClientService:HttpClientService,private router: Router,
  ) { }

  ngOnInit() {
    this.httpClientService.getEmployees().subscribe(
     response =>this.handleSuccessfulResponse(response),
    );
  }

handleSuccessfulResponse(response)
{
    this.employees=response;
}


deleteEmployee(empid): void {
  this.httpClientService.deleteEmployee(empid)
    .subscribe( data => {
      console.log(data);
      this.ngOnInit();
    })
};

/*updateEmployee(empid){
  this.httpClientService.getEmployee(empid)
  .subscribe(data => {
    console.log("data"+data)
    this.user = data;
    this.gotoList();
  }, error => console.log(error));
}
gotoList() {
  this.router.navigate(['/updateemployee']);
} */

}
