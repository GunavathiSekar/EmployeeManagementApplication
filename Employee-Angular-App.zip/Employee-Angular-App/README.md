Follow the instructions to start the application

npm install

npm start


Access the link by 
http://localhost:4200
